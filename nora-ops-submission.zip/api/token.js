export default async function handler(req, res) {
  // Enable CORS
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version'
  );

  if (req.method === 'OPTIONS') {
    res.status(200).end();
    return;
  }

  const NAPSTER_API_KEY = process.env.NAPSTER_API_KEY;
  const AGENT_ID = process.env.AGENT_ID || '132c2e86-432b-4507-bc8b-a34e95e1ff5c';
  const API_BASE = process.env.COMPANION_API_BASE || 'https://companion-api.napster.com';

  if (!NAPSTER_API_KEY) {
    res.status(500).json({ error: 'Missing NAPSTER_API_KEY in environment variables.' });
    return;
  }

  try {
    const response = await fetch(`${API_BASE}/public/agents/${AGENT_ID}/connections`, {
      method: 'POST',
      headers: {
        'X-Api-Key': NAPSTER_API_KEY,
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
      },
      body: JSON.stringify({ channelType: 'webrtc' })
    });

    if (!response.ok) {
      const errText = await response.text();
      res.status(response.status).json({ error: errText });
      return;
    }

    const data = await response.json();
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: String(err.message || err) });
  }
}
